﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IRunesWebApp.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\mssqllocaldb;Database=IRunesDb; Integrated Security=True;";
    }
}
