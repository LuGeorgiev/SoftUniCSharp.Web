﻿namespace SIS.Http.Enums
{
    public enum HttpRequestMethod
    {
        GET,
        POST,
        PUT,
        DELETE
    }
}
